package main

func main() {

	//切片的循环遍历

	// var strSlice = []string{"php", "java", "nodejs", "golang"}
	// for i := 0; i < len(strSlice); i++ {
	// 	fmt.Println(strSlice[i])
	// }

	// var strSlice = []string{"php", "java", "nodejs", "golang"}
	// for k, v := range strSlice {
	// 	fmt.Println(k, v)
	// }

}
