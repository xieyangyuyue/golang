package tools

import "fmt"

func PrintInfo() {
	fmt.Println("打印信息")
}
