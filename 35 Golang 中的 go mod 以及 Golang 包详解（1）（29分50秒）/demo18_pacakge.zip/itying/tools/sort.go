package tools

import "fmt"

func SortIntAsc() {
	fmt.Println("按照升序对int切片排序")
}
